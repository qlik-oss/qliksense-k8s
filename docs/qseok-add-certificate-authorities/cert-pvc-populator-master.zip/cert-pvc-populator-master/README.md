# cert-pvc-populator

Helm chart for to populate a PVC with certs.

## Introduction

This chart starts a run-once job that populates a PVC with a standard list of CA certs from a source image. 
It also supports adding additional certs on top of the standard list.

## Installing the Chart

To install the chart with the release name `my-release`:

```console
helm install --name my-release qlik/cert-pvc-populator
```

The command deploys `cert-pvc-populator` on the Kubernetes cluster in the default configuration. 
The [configuration](#configuration) section lists the parameters that can be configured during installation.

## Uninstalling the Chart

To uninstall/delete the `my-release` deployment:

```console
helm delete --purge my-release
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following tables lists the configurable parameters of the `cert-pvc-populator` chart and their default values.

| Parameter                    | Description                                                              | Default                                                  |
| ---------------------------- | -------------------------------------------------------------------------| -------------------------------------------------------- |
| `image.repository`           | image to grab the base list of standard CA certs from                    | `golang`                                                 |
| `image.tag`                  | image version                                                            | `alpine`                                                 |
| `image.pullPolicy`           | image pull policy                                                        | `Always` if `image.tag` is `latest`, else `IfNotPresent` |
| `image.publicCAFilePath`     | path to the public certificate file on the selected image                | `/etc/ssl/certs/ca-certificates.crt`                     |
| `job.volumeClaimName`        | Volume to write certs to                                                 | `certs-pvc`                                              |
| `job.customCA`               | Base64 encoded list of ca certs to add to the standard certs             | CA cert for `example`                                    |
| `pvc.create`                 | Optionally, this chart can create the PVC that it writes certs to.       | `false`                                                  |
| `pvc.storageClass`           | Which storageClass should the pvc use                                    |                                                          |

Specify each parameter using the `--set key=value[,key=value]` argument to `helm install`.

Alternatively, a YAML file that specifies the values for the parameters can be provided while installing the chart. For example,

```console
helm install --name my-release -f values.yaml qlik/cert-pvc-populator --set pvc.create=true,pvc.storageClass=fast
```
